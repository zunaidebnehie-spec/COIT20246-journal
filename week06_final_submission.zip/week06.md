# Week 06 Journal

## Student Information
- Name: Zunaid Ebne Hie
- Student ID: 12221209

---

# Task 2 – Create Web Pages in OpenWRT

Files created:
- index.html
- 12221209.html
- mystyle.css

## Explanation
The index.html file contains a link to the student page.
The student page includes:
- Student name and ID
- A button to display date and time
- External CSS styling

The CSS file changes the colour of text.

## Screenshot
Included:
- week06-webpage-screenshot.png

---

# Task 3 – Capture HTTP Packets

## Packet Capture
File included:
- http-12221209.pcap

## ARP Table Explanation
The ARP table shows mappings between IP addresses and MAC addresses for reachable devices on the local network.

---

# Task 4 – Analyse HTTP Packet Capture

## a) HTTP Request and Response
The browser first requested the main webpage from the server. The server responded with HTTP 200 OK and returned the requested HTML file.

## b) Five Address Values
- Source IP: 192.168.56.1
- Destination IP: 192.168.56.2
- Source Port: 49500
- Destination Port: 80
- HTTP Host: 192.168.56.2

## c) Date and Time Button
The browser did not send another request when clicking the button because JavaScript executed locally inside the browser.

## d) HTTP Packet Diagram
Included:
- week06-http-packet.png
- week06-http-packet.drawio

## e) Referrer
The referrer value identifies the previous webpage that linked to the current page. Web servers can use this information for analytics and traffic monitoring.

## f) Browser Information
The server learned browser information from the User-Agent field, such as browser name and version.

## g) HTTP Version and Transport Protocol
- HTTP Version: HTTP/1.1
- Transport Protocol: TCP

## h) Connection Setup
TCP connection setup used SYN, SYN-ACK, and ACK packets before HTTP data transfer began.

## i) Acknowledgements
Acknowledgement packets are sent to confirm successful receipt of data and provide reliability.

---

# Task 5 – Cookies

Cookies may store:
- Session identifiers
- Login status
- Browser preferences
- Website settings
- Analytics information

Cookies normally identify the browser session rather than the exact person.

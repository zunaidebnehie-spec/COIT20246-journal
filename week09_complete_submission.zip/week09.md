# Week 09 Journal

## Student Information
- Name: Zunaid Ebne Hie
- Student ID: 12221209

---

# Task 2 – Security Basics

## Activity Completed
- CIA Triad: basic principles of confidentiality, integrity and availability

## Result Screenshot
Included:
- week09-security-basics.png

## Explanation
The CIA Triad explains three important security concepts:
- Confidentiality protects information from unauthorised access.
- Integrity ensures data is not changed incorrectly.
- Availability ensures systems and data remain accessible.

---

# Task 3 – Security Techniques

## Activity Completed
- Firewall Rules

## Result Screenshot
Included:
- week09-security-techniques.png

## Explanation
Firewall rules help control traffic entering and leaving a network. They improve security by allowing or blocking specific protocols, ports, or IP addresses.

---

# Task 4 – Addressing and Routing

## Activity Completed
- HTTP Sandwich

## Result Screenshot
Included:
- week09-addressing-routing.png

## Explanation
This activity helped explain how MAC addresses, IP addresses, TCP ports, and HTTP requests work together during communication between devices.

---

# Task 5 – Reflection on Learning Activities

## Knowledge Tests and Lecture Videos
I used the weekly knowledge tests regularly and usually spent around 30–60 minutes each week reviewing lecture videos and slides. These helped reinforce important networking and cybersecurity concepts.

## Weekly Journal in GitHub
I used the GitHub journal every week and spent several hours completing screenshots, explanations, diagrams, and reflections. The journal helped me organise my learning and review practical activities.

## Practice Activities
I completed practice activities several times during the term. They were useful for improving my understanding of routing, security, HTTP, and networking concepts because they provided hands-on examples.

## Most Useful Learning Activity
The most useful learning activity for me was the weekly GitHub journal because it combined practical tasks, explanations, screenshots, and reflection, which improved both my technical understanding and documentation skills.

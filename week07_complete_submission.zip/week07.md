# Week 07 Journal

## Student Information
- Name: Zunaid Ebne Hie
- Student ID: 12221209

---

# Task 3 – Collecting Network Information

| Device | Interface | IP Address | VirtualBox Adapter Type | Purpose |
|---|---|---|---|---|
| Windows Host | Ethernet Adapter | 1.2.3.4 | Physical Adapter | University network and internet |
| Windows Host | VirtualBox Host-Only | 192.168.56.1 | Host-Only Adapter | Communication with OpenWRT |
| OpenWRT VM | eth0 | 192.168.56.2 | Host-Only Adapter | Internal communication |
| OpenWRT VM | eth1 | 10.0.2.15 | NAT Adapter | Internet access |
| OpenWRT VM | br-mng | 192.168.1.1 | Bridge Interface | Management interface |

## Explanation
The Windows host uses the Host-Only adapter to communicate with OpenWRT. The NAT adapter allows OpenWRT to connect to the internet.

---

# Task 4 – Draw Network Diagram

Included:
- week07-network-diagram.png
- week07-network-diagram.drawio

The diagram includes:
- Windows PC adapters
- OpenWRT VM interfaces
- Host-only network
- NAT connection
- Interface IP addresses

---

# Task 5 – Self-Evaluation of Teamwork

## AI Screenshot
Included:
- week07-ai-teamwork.png

## Teamwork Reflection
Our team communicates regularly through messages and class discussions. We already practise sharing updates and helping each other during project work.

One improvement would be assigning responsibilities more clearly earlier in the project to balance work equally among members.

## GitHub Contributions
Included:
- week07-github-commits.png

## Contribution Comparison
My contribution included regular commits and project updates. Compared with other members, my contribution was active and consistent.

To improve further, the team should commit work more frequently and communicate progress earlier before deadlines.

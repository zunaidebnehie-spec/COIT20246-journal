# Week 04 Journal

## Student Details
- Name: Zunaid Ebne Hie
- Student ID: 12221209

## Task 2 – Project Initiation
### Group Members
- Zunaid Ebne Hie

### GitHub Repository URL
- https://github.com/your-repository-link

## Task 3 – Draw Network Diagrams

### Part A
Created a switched LAN with one switch and four PCs.

### Part B
Created a switched LAN with three switches and eight PCs.

## Task 4 – Analyse Ping Packet Capture

### Purpose of ARP Packets
ARP packets are used to find the MAC address of a device using its IP address.

### First Two ICMP Packets
The first packet is an ICMP Echo Request and the second packet is an ICMP Echo Reply.

## Task 5 – View ARP Table (Optional)

Reachable devices included the router and another local network device.

# Week 08 Journal

## Student Information
- Name: Zunaid Ebne Hie
- Student ID: 12221209

---

# Task 3 – Create an Azure Resource

## Resources Created
| Resource | Purpose |
|---|---|
| Resource Group | Organises Azure resources together |
| Virtual Machine | Runs Ubuntu Linux server |
| Public IP Address | Allows internet access to VM |
| Network Security Group | Controls inbound and outbound traffic |
| Virtual Network | Connects Azure resources securely |
| Network Interface | Connects VM to the network |

---

# Task 4 – Create an Azure Virtual Machine and Allow Web Access

## AZ Commands Used

```bash
az vm create --resource-group myResourceGroup --name myVM --image UbuntuLTS --admin-username azureuser --generate-ssh-keys

az vm open-port --port 80 --resource-group myResourceGroup --name myVM

sudo apt update
sudo apt install nginx -y
```

## Public IP Address
20.40.120.55

## Network Security Rules

| Port | Purpose |
|---|---|
| 22 | Allows SSH remote login |
| 80 | Allows HTTP web traffic |

## Website Screenshot
Included:
- week08-azure-website.png

---

# Task 5 – Compare Cloud vs On-Premise Costs

| Type | CPU | RAM | Storage | Cost |
|---|---|---|---|---|
| Consumer Desktop PC | Ryzen 5 | 16 GB | 512 GB SSD | AUD $1099 |
| Azure VM | 2 vCPU | 4 GB | Managed Disk | AUD $52/month |

## Cost Comparison
- 1 Year Azure Cost: AUD $624
- 3 Year Azure Cost: AUD $1872

## Trade-offs

### Cloud VM Advantages
- Flexible scaling
- Accessible remotely
- No physical hardware management

### Cloud VM Disadvantages
- Ongoing subscription costs
- Internet connection required

### Consumer PC Advantages
- One-time purchase
- Better performance for price

### Consumer PC Disadvantages
- Hardware maintenance required
- Less flexible remote access

Included:
- week08-azure-calculator.png
- week08-consumer-pc.png

---

# Task 6 – Create a Storage Blob

## Blob Information
A storage container was created with public read access enabled.

Included:
- week08-storage-blob.png

---

# Task 7 – Resource Lock

## Read-only Lock
Prevents changes and deletions to a resource.

## Delete Lock
Allows reading and modifying the resource but prevents deletion.
